# Profiling diagnostic only; instrumentation changes runtime costs.
import importlib.util,sys,os,subprocess,json
from pathlib import Path
root=Path('/Users/edgar/.codex/worktrees/strict-parser-optimization/json_blueprint')
sys.path.insert(0,str(root/'scripts'));import parser_benchmark as b
out=Path('/tmp/strict-parser-optimization-evidence')/(sys.argv[1] if len(sys.argv)>1 else 'profiles');out.mkdir(exist_ok=True)
for case in b.representative_fixtures():
 if case.name not in ['record','response_50','text_plain','text_unicode']:continue
 p=out/(case.name+'.json');p.write_text(case.text)
 for target in ('erlang','javascript'):
  n=(500 if case.name=='record' else 20) if target=='erlang' else (20000 if case.name=='record' else 250)
  env=os.environ|{'BLUEPRINT_PARSER_INPUT':str(p),'BLUEPRINT_PARSER_ACCEPTED':'true','BLUEPRINT_PARSER_BACKEND':'strict','BLUEPRINT_PARSER_MODE':'timing','BLUEPRINT_PARSER_ITERATIONS':str(n)}
  cmd=b.runtime_command(target)
  if target=='erlang':
   cmd[-1]='eprof:start(), eprof:profile([], fun parser_benchmark_runner:main/0), eprof:analyze(total), halt().'
  else:cmd[1:1]=['--cpu-prof','--cpu-prof-dir='+str(out),'--cpu-prof-name='+case.name+'.cpuprofile']
  with (out/(case.name+'-'+target+'.txt')).open('w') as f:
   subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
  print(case.name,target,flush=True)
