import sys,subprocess,os,json,statistics,hashlib
from pathlib import Path
base=Path('/Users/edgar/.codex/worktrees')
roots={'baseline':base/'parser-optimization-baseline/json_blueprint','batched':base/'strict-parser-optimization/json_blueprint','pair':base/'parser-index-scan/json_blueprint'}
sys.path.insert(0,str(roots['batched']/'scripts'));import parser_benchmark as b
out=Path('/tmp/strict-parser-optimization-evidence/alternating-pair');out.mkdir(exist_ok=True)
for root in roots.values():
 subprocess.run(['gleam','format','src/json/blueprint/value.gleam'],cwd=root,check=True)
 for t in ('erlang','javascript'):subprocess.run(['gleam','build','--target',t,'--warnings-as-errors'],cwd=root,check=True)
fixtures=b.representative_fixtures()+[f for f in b.fixtures() if f.name in ['escaped_unicode','object_500','dense_10000']]
rows=[]
for f in fixtures:
 p=out/(f.name+'.json');p.write_text(f.text);n=max(1,min(200,100000//len(f.text.encode())))
 for t in ('erlang','javascript'):
  for trial in range(3):
   order=list(roots);order=order[trial:]+order[:trial]
   for variant in order:
    b.ROOT=roots[variant]
    env=os.environ|{'BLUEPRINT_PARSER_INPUT':str(p),'BLUEPRINT_PARSER_BACKEND':'strict','BLUEPRINT_PARSER_ACCEPTED':'true','BLUEPRINT_PARSER_MODE':'timing','BLUEPRINT_PARSER_ITERATIONS':str(n)}
    output,_=b.run_process(b.runtime_command(t),env)
    rows.append(dict(fixture=f.name,target=t,variant=variant,trial=trial,batch_ns=output))
  print(f.name,t,flush=True)
(out/'raw.json').write_text(json.dumps(rows,indent=2))
summary=[]
for f in fixtures:
 for t in ('erlang','javascript'):
  for v in roots:
   ts=[statistics.median(r['batch_ns']) for r in rows if (r['fixture'],r['target'],r['variant'])==(f.name,t,v)]
   summary.append(dict(fixture=f.name,target=t,variant=v,median_ns=statistics.median(ts),range_ns=[min(ts),max(ts)]))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
(out/'source-hashes.json').write_text(json.dumps({v:{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['src/json/blueprint/value.gleam','src/json_blueprint_ffi.mjs','scripts/parser_benchmark.py','test/parser_benchmark_runner.gleam']} for v,root in roots.items()},indent=2))
