import sys,os,json,hashlib
from pathlib import Path
roots={'baseline':Path('/Users/edgar/.codex/worktrees/parser-optimization-baseline/json_blueprint'),'final':Path('/Users/edgar/.codex/worktrees/strict-parser-optimization/json_blueprint')}
sys.path.insert(0,str(roots['final']/'scripts'));import parser_benchmark as b
out=Path('/tmp/strict-parser-optimization-evidence/memory');out.mkdir(exist_ok=True)
rows=[]
for f in b.fixtures():
 if f.name not in ['dense_value_limit','escaped_unicode']:continue
 p=out/(f.name+'.json');p.write_text(f.text)
 for t in ('erlang','javascript'):
  for trial in range(3):
   for v in (['baseline','final'] if trial%2==0 else ['final','baseline']):
    b.ROOT=roots[v];env=os.environ|{'BLUEPRINT_PARSER_INPUT':str(p),'BLUEPRINT_PARSER_BACKEND':'strict','BLUEPRINT_PARSER_ACCEPTED':'true','BLUEPRINT_PARSER_MODE':'memory'}
    result,peak=b.run_process(b.runtime_command(t),env);assert result=={'accepted':True}
    rows.append(dict(fixture=f.name,target=t,variant=v,trial=trial,peak_rss_bytes=peak))
(out/'results.json').write_text(json.dumps(rows,indent=2))
print('Memory stress comparison completed')
